Splunk Add-on for CyberArk version 1.0.0
Copyright (C) 2009-2015 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/AddOns/latest/CyberArk/About
